'use strict';

var motoAdsServices = angular.module('motoAdsServices', ['ngResource']);

motoAdsServices.factory('Brand', ['$resource', function($resource) {
    return $resource('/api/brands', {}, {});
  }]);

motoAdsServices.factory('Country', ['$resource', function($resource) {
    return $resource('/api/countries', {}, {});
  }]);

motoAdsServices.factory('Advert', ['$resource', function($resource) {
    return $resource('/api/adverts/:advertId', {}, {
       update: {method:'PUT', params: {advertId: '@_id'}}
    });
  }]);

//newly added
//var svd3ChartServices = angular.module('svd3ChartServices', ['ngResource']);

motoAdsServices.factory('Chart', ['$resource', function($resource) {
    	return $resource('/api/linechart', {}, {});   
  }]);

motoAdsServices.factory('LinePlusBarChart', ['$resource', function($resource) {
	return $resource('/api/linePlusBarChart', {}, {});   
}]);

motoAdsServices.factory('StackedAreaChart', ['$resource', function($resource) {
	return $resource('/api/stackedAreaChart', {}, {});   
}]);

motoAdsServices.factory('TreeGridChart', ['$resource', function($resource) {
	return $resource('/api/treeGridChart', {}, {});   
}]);

motoAdsServices.factory('HierarchicalBarChart', ['$resource', function($resource) {
	return $resource('/api/hierarchicalBarChart', {}, {});   
}]);


motoAdsServices.factory('ngGridChart', ['$resource', function($resource) {
	return $resource('/api/ngGridChart', {}, {});   
}]);

motoAdsServices.factory('crossfilterChart', ['$resource', function($resource) {
	return $resource('/api/crossfilterChart', {}, {});   
}]);

