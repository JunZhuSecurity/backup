'use strict';

var motoAdsApp = angular.module('motoAdsApp', ['ngRoute', 'ngSanitize', 'ui.bootstrap', 'motoAdsServices', 'nvd3ChartDirectives', 'treeGrid', 'hierarchicalBar', 'ngGrid']);
//var svd3ChartApp = angular.module('svd3ChartApp', ['nvd3ChartDirectives', 'svd3ChartServices']);

motoAdsApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
            when('/', {
              controller: 'AdvertsController',
              templateUrl: 'views/adverts.html'
            }).
            when('/addAdvert', {
              controller: 'AddAdvertController',
              templateUrl: 'views/addAdvert.html'
            }).
            when('/editAdvert/:advertId', {
              controller: 'EditAdvertController',
              templateUrl: 'views/editAdvert.html'
            }).
            when('/lineChart', {
                controller: 'lineChartTickValueCtrl',
                templateUrl: 'views/lineChart.html'
              }).
            //attention!!!!! it is . not ;
    when('/linePlusBarChart', {
        controller: 'linePlusBarChartCtrl',
        templateUrl: 'views/linePlusBarChart.html'
      }). //attention!!!! if it is the last when, then, 
         
            //attention!!!!! it is . not ;
    when('/stackedAreaChart', {
        controller: 'stackedAreaChartCtrl',
        templateUrl: 'views/stackedAreaChart.html'
      }). //attention!!!! if it is the last when, then,    
      
      //newly added
  //attention!!!!! it is . not ;
  when('/treeGridChart', {
      controller: 'treeGridChartCtrl',
      templateUrl: 'views/treeGridChart.html'
    }).
    
    when('/hierarchicalBarChart', {
        controller: 'hierarchicalBarChartCtrl',
        templateUrl: 'views/hierarchicalBarChart.html'
      }).
      
      when('/ngGridChart', {
          controller: 'ngGridChartCtrl',
          templateUrl: 'views/ngGridChart.html'
        });
    
            
  }]); 


//svd3ChartApp.config(['$routeProvider',
//                   function($routeProvider) {
//                     $routeProvider.
//                     when('/linechart', {
//                       controller: 'lineChartTickValueCtrl',
//                       templateUrl: 'views/lineChart.html'
//                     });
//}]);