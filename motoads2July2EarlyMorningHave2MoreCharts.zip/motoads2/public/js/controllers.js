//'use strict';

motoAdsApp.controller('NavbarController', function NavbarController($scope, $location) {

  $scope.routeIs = function(routeName) {
    return $location.path() === routeName;
  };

});

motoAdsApp.controller('AdvertsController', ['$scope', '$filter', '$window', 'Brand', 'Country', 'Advert',
  function($scope, $filter, $window, Brand, Country, Advert) {
    $scope.oneAtATime = true;

    $scope.brands = Brand.query();

    $scope.countries = Country.query();

    $scope.sortByCols = [{
        "key": "year",
        "name": "Year"
      }, {
        "key": "price",
        "name": "Price"
      }];

    $scope.sortAdverts = function(sortKey) {
      if (sortKey) {
        console.log('sortKey = ' + sortKey);
        $scope.adverts = $filter('orderBy')($scope.adverts, sortKey);
      }
    };

    $scope.adverts = [];
    var allAdverts = Advert.query(filterAdverts);

    $scope.filter = {
      brandName: null,
      modelName: null,
      country: null,
      region: null,
      yearFrom: null,
      yearTo: null
    };

    $scope.isAnyFilter = function() {
      var f = $scope.filter;
      if (f.brandName || f.modelName || f.country || f.region || f.yearFrom || f.yearTo) {
        return true;
      }
      return false;
    };

    $scope.removeAllFilter = function() {
      $scope.filter = {
        brandName: null,
        modelName: null,
        country: null,
        region: null,
        yearFrom: null,
        yearTo: null
      };
    };

    $scope.addBrandModelFilter = function(brand, model) {
      $scope.filter.brandName = brand.name;
      $scope.filter.modelName = model.name;
    };

    $scope.$watch('filter', filterAdverts, true);

    function filterAdverts() {
      $scope.adverts = [];
      angular.forEach(allAdverts, function(row) {
        if (!$scope.filter.country) {
          $scope.filter.region = null;
        }
        if ($scope.filter.brandName && $scope.filter.brandName !== row.brandName) {
          return;
        }
        if ($scope.filter.modelName && $scope.filter.modelName !== row.modelName) {
          return;
        }
        if ($scope.filter.country && $scope.filter.country.name !== row.countryName) {
          return;
        }
        if ($scope.filter.region && $scope.filter.region.name !== row.regionName) {
          return;
        }
        if ($scope.filter.yearFrom && $scope.filter.yearFrom > row.year) {
          return;
        }
        if ($scope.filter.yearTo && $scope.filter.yearTo < row.year) {
          return;
        }
        $scope.adverts.push(row);
      });
      $scope.adverts = $filter('orderBy')($scope.adverts, ['brandName', 'modelName']);
    }

    $scope.removeAdvert = function(idx) {
      var removeAdvert = $scope.adverts[idx];
      Advert.remove({advertId: removeAdvert._id}, function() {
        $scope.adverts.splice(idx, 1);
        alert('Advert removed');
      });
    };

    $scope.editAdvert = function(_advertId) {
      $window.location = "#/editAdvert/" + _advertId;
    };
  }]);

motoAdsApp.controller('CommentController', ['$scope',
  function($scope) {
    $scope.commentModeOn = false;
    
    $scope.isAnyComment = function() {
      return ($scope.advert.comments.length > 0);
    };
  }]);

motoAdsApp.controller('AddAdvertController', ['$scope', '$window', 'Brand', 'Country', 'Advert',
  function($scope, $window, Brand, Country, Advert) {
    $scope.brands = Brand.query();

    $scope.countries = Country.query();

    var emptyAdvert = {
      brandName: null,
      modelName: null,
      year: 2010,
      price: 10000,
      imageUrl: "img/audi_a1_1.jpg",
      countryName: null,
      regionName: null
    };

    $scope.addAdvert = function() {
      Advert.save($scope.newAdvert, function() {
        alert('New advert added');
        // if not return to #/
        //$scope.resetAdvert();
        $window.location = "#/";
      });
    };

    $scope.resetAdvert = function() {
      $scope.brand = null;
      $scope.model = null;
      $scope.country = null;
      $scope.region = null;
      $scope.newAdvert = angular.copy(emptyAdvert);
      if ($scope.advertForm) {
        $scope.advertForm.$setPristine();
      }
    };

    $scope.isUnchanged = function() {
      return angular.equals($scope.newAdvert, emptyAdvert);
    };

    $scope.resetAdvert();
  }]);

motoAdsApp.controller('EditAdvertController', ['$scope', '$routeParams', '$window', 'Brand', 'Country', 'Advert',
  function($scope, $routeParams, $window, Brand, Country, Advert) {
    $scope.brands = Brand.query();

    function currentBrandAndModel(brandName, modelName) {
      angular.forEach($scope.brands, function(item) {
        if (item.name === brandName) {
          $scope.brand = item;
          return;
        }
      });

      angular.forEach($scope.brand.models, function(item) {
        if (item.name === modelName) {
          $scope.model = item;
          return;
        }
      });
    }

    $scope.countries = Country.query();

    function currentCountryAndRegion(countryName, regionName) {
      angular.forEach($scope.countries, function(item) {
        if (item.name === countryName) {
          $scope.country = item;
          return;
        }
      });

      angular.forEach($scope.country.regions, function(item) {
        if (item.name === regionName) {
          $scope.region = item;
          return;
        }
      });
    }

    var previousAdvert = null;
    $scope.editAdvert = Advert.get({advertId: $routeParams.advertId}, function() {
      currentBrandAndModel($scope.editAdvert.brandName, $scope.editAdvert.modelName);
      currentCountryAndRegion($scope.editAdvert.countryName, $scope.editAdvert.regionName);
      previousAdvert = angular.copy($scope.editAdvert);
    });

    $scope.updateAdvert = function() {
      Advert.update($scope.editAdvert, function() {
        // if not return to #/
        //previousAdvert = angular.copy($scope.editAdvert);
        alert('Advert updated');
        $window.location = "#/";
      });
    };

    $scope.isUnchanged = function() {
      return angular.equals($scope.editAdvert, previousAdvert);
    };

    $scope.resetAdvert = function() {
      $scope.editAdvert = angular.copy(previousAdvert);
      if ($scope.advertForm) {
        $scope.advertForm.$setPristine();
      }
    };
  }]);

//below are newly added

//svd3ChartApp.

motoAdsApp.controller('lineChartTickValueCtrl', ['$scope', 'Chart',
                                               function($scope, Chart) {
$scope.exampleData = Chart.query();
	  console.log('line chart controller executed');
	  
//	  $scope.exampleData = [
//	                        {
//	                            "key": "Github Api Mean Web Response Time",
//	                            "values": [[1378387200.0, 123.08370666666667], [1378387500.0, 119.64371999999999], [1378387800.0, 126.92131333333332], [1378388100.0, 122.06958666666667], [1378388400.0, 126.50453], [1378388700.0, 168.14301666666668], [1378389000.0, 132.83243], [1378389300.0, 137.11919333333336], [1378389600.0, 152.85155], [1378389900.0, 133.26816], [1378390200.0, 178.5094466666667], [1378390500.0, 156.0947666666667]]
//	                        }];

	                    $scope.xAxisTickValuesFunction = function(){
	                        return function(d){
	                            var tickVals = [];
	                            var values = d[0].values;
	                            var interestedTimeValuesArray = [0, 00, 15, 30, 45];
	                            for(var i in values){
	                                if(interestedTimeValuesArray.indexOf(moment.unix(values[i][0]).minute()) >= 0){
	                                    tickVals.push(values[i][0]);
	                                }
	                            }
	                            console.log('xAxisTickValuesFunction', d);
	                            return tickVals;
	                        };
	                    };

	                    $scope.xAxisTickFormatFunction = function(){
	                        return function(d){
	                            return d3.time.format('%H:%M')(moment.unix(d).toDate());
	                        }
	                    };
}
]);




motoAdsApp.controller('linePlusBarChartCtrl', ['$scope', 'LinePlusBarChart',
                                                 function($scope, LinePlusBarChart) {
  $scope.exampleData = LinePlusBarChart.query();
  	  console.log('LinePlusBarChart chart controller executed');
  	  
//  	  $scope.exampleData = [
//  	                        {
//  	                            "key": "Github Api Mean Web Response Time",
//  	                            "values": [[1378387200.0, 123.08370666666667], [1378387500.0, 119.64371999999999], [1378387800.0, 126.92131333333332], [1378388100.0, 122.06958666666667], [1378388400.0, 126.50453], [1378388700.0, 168.14301666666668], [1378389000.0, 132.83243], [1378389300.0, 137.11919333333336], [1378389600.0, 152.85155], [1378389900.0, 133.26816], [1378390200.0, 178.5094466666667], [1378390500.0, 156.0947666666667]]
//  	                        }];
  	$scope.y1axislabeltext = "Y1 Axis Label";
    $scope.y2axislabeltext = "Y2 Axis Label";

    $scope.xAxisTickFormat = function(){
        return function(d){
            return d3.time.format('%x')(new Date(d));  //uncomment for date format
        }
    }

    $scope.y1AxisTickFormat = function(){
        return function(d){
            return d3.format(',f')(d);
        }
    }
    $scope.y2AxisTickFormat = function(){
        return function(d){
            return '$' + d3.format(',.2f')(d);
        }
    }
  	                   
  }
  ]);

motoAdsApp.controller('stackedAreaChartCtrl', ['$scope', 'StackedAreaChart',
                                               function($scope, StackedAreaChart) {
$scope.exampleData = StackedAreaChart.query(); //change accordingly 

$scope.xAxisTickFormat = function(){
    return function(d){
        return d3.time.format('%x')(new Date(d));
    }
};

$scope.toolTipContentFunction = function(){
    return function(key, x, y, e, graph) {
        console.log('tooltip content');
        return  'Super New Tooltip' +
                '<h1>' + key + '</h1>' +
                '<p>' +  y + ' at ' + x + '</p>'
    }
};
	                   
}
]);

//newly added
motoAdsApp.controller('treeGridChartCtrl', ['$scope', 'TreeGridChart', '$timeout',
                                               function($scope, TreeGridChart, $timeout) {

var tree;
    
    var rawTreeData = [
               		{"DemographicId":1,"ParentId":null,"Name":"United States of America","Description":"United States of America", "Area":9826675,"Population":318212000,"TimeZone":"UTC -5 to -10"},
            		{"DemographicId":2,"ParentId":1,"Name":"California","Description":"The Tech State","Area":423970,"Population":38340000,"TimeZone":"Pacific Time"},
            		{"DemographicId":3,"ParentId":2,"Name":"San Francisco","Description":"The happening city","Area":231,"Population":837442,"TimeZone":"PST"},
            		{"DemographicId":4,"ParentId":2,"Name":"Los Angeles","Description":"Disco city","Area":503,"Population":3904657,"TimeZone":"PST"},
            		{"DemographicId":5,"ParentId":1,"Name":"Illinois","Description":"Not so cool","Area":57914,"Population":12882135,"TimeZone":"Central Time Zone"},
            		{"DemographicId":6,"ParentId":5,"Name":"Chicago","Description":"Financial City","Area":234,"Population":2695598,"TimeZone":"CST"},
            		{"DemographicId":7,"ParentId":1,"Name":"Texas","Description":"Rances, Oil & Gas","Area":268581,"Population":26448193,"TimeZone":"Mountain"},
            		{"DemographicId":8,"ParentId":1,"Name":"New York","Description":"The largest diverse city","Area":141300,"Population":19651127,"TimeZone":"Eastern Time Zone"},
            		{"DemographicId":14,"ParentId":8,"Name":"Manhattan","Description":"Time Square is the place","Area":269.403,"Population":0,"TimeZone":"EST"},
            		{"DemographicId":15,"ParentId":14,"Name":"Manhattan City","Description":"Manhattan island","Area":33.77,"Population":0,"TimeZone":"EST"},
            		{"DemographicId":16,"ParentId":14,"Name":"Time Square","Description":"Time Square for new year","Area":269.40,"Population":0,"TimeZone":"EST"},
            		{"DemographicId":17,"ParentId":8,"Name":"Niagra water fall","Description":"Close to Canada","Area":65.7,"Population":0,"TimeZone":"EST"},
            		{"DemographicId":18,"ParentId":8,"Name":"Long Island","Description":"Harbour to Atlantic","Area":362.9,"Population":0,"TimeZone":"EST"},
            		{"DemographicId":51,"ParentId":1,"Name":"All_Other","Description":"All_Other demographics","Area":0,"Population":0,"TimeZone":0},
            		{"DemographicId":201,"ParentId":null,"Name":"India","Description":"Hydrabad tech city", "Area":9826675,"Population":318212000,"TimeZone":"IST"},
            		{"DemographicId":301,"ParentId":null,"Name":"Bangladesh","Description":"Country of love", "Area":9826675,"Population":318212000,"TimeZone":"BST"}
            		];

    
    var myTreeData = getTree(rawTreeData, 'DemographicId', 'ParentId');

    $scope.tree_data = myTreeData;    
    $scope.my_tree = tree = {};
    $scope.expanding_property = "Name";
    $scope.col_defs = [
    	{ field: "Description"},
    	{ field: "Area"},
    	{ field: "Population"},
    	{ field: "TimeZone", displayName: "Time Zone"}
    ];
    $scope.my_tree_handler = function(branch){
    	console.log('you clicked on', branch)
    }
    
function getTree(data, primaryIdName, parentIdName){
	if(!data || data.length==0 || !primaryIdName ||!parentIdName)
		return [];

	var tree = [],
		rootIds = [],
		item = data[0],
		primaryKey = item[primaryIdName],
		treeObjs = {},
		parentId,
		parent,
		len = data.length,
		i = 0;
	
	while(i<len){
		item = data[i++];
		primaryKey = item[primaryIdName];			
		treeObjs[primaryKey] = item;
		parentId = item[parentIdName];

		if(parentId){
			parent = treeObjs[parentId];	

			if(parent.children){
				parent.children.push(item);
			}
			else{
				parent.children = [item];
			}
		}
		else{
			rootIds.push(primaryKey);
		}
	}

	for (var i = 0; i < rootIds.length; i++) {
		tree.push(treeObjs[rootIds[i]]);
	};

	return tree;
}

	                   
}
]);


//newly added          
motoAdsApp.controller('hierarchicalBarChartCtrl', ['$scope', 'HierarchicalBarChart', 
                                               function($scope, HierarchicalBarChart) {
    console.log("reach the controller of hier");
    $scope.data = HierarchicalBarChart.query();    
    console.log("data from db is = " + $scope.data);
}
]);


//newly added          
motoAdsApp.controller('ngGridChartCtrl', function($scope) {
    $scope.myData = [{"name": "Kyle Hayhurst", "age": 25, "interest": "interestfdsf", "id": 1},
                     {"name": "fd", "age": 25, "interest": "interestfdsf", "id": 3},
                     {"name": "fdsf", "age": 27, "interest": "interestfdsf", "id": 4},
                     {"name": "fdsfs", "age": 29, "interest": "interestfdsf", "id": 6},
                     {"name": "fdsf", "age": 28, "interest": "interestfdsf", "id": 2}];
    	
//    	[{name: 'Kyle Hayhurst', age: 25, interest: 'Javascript', id: 1},
//                     {name: 'Jimmy Hampton', age: 25, interest: 'HTML', id: 3},
//                     {name: 'Tim Sweet', age: 27, interest: 'HTML', id: 4},
//                     {name: 'Jonathon Ricaurte', age: 29, interest: 'CSS', id: 6},
//                     {name: 'Brian Hann', age: 28, interest: 'PHP', id: 2}];
    $scope.gridOptions = { 
        data: 'myData',
        showGroupPanel: true,
        columnDefs: [{field: 'name', displayName: 'Name'},
            {field: 'age', displayName: 'Age'},
            {field: 'interest', displayName: 'Interest'},
            {displayName: 'Options', cellTemplate: '<input type="button" name="view" onclick="alert(\'You clicked view on item ID: {{row.entity.id}} \')" value="View">&nbsp;<input type="button" name="edit" onclick="alert(\'You clicked edit on item ID: {{row.entity.id}} \')" value="Edit">&nbsp;<input type="button" onclick="alert(\'You clicked delete on item ID: {{row.entity.id}} \')" name="delete" value="Delete">'}
            ]
    };
});

