<link rel="stylesheet" href="css/bootstrap-combined.min.css">
  <link rel="stylesheet" href="css/timetree_basic.css">
  <link rel="stylesheet" href="css/timetree_chrome_devtools.css">
  <link rel="stylesheet" href="css/emberTreeEx.css">



  <div id="app"></div>

  <script type="text/x-handlebars" data-template-name="index">
 

    <div class="example">
      <h3>Example #2: Brush View</h3>

      <figcaption>
        <p>
          Same data as before, but there is a 2nd view at the bottom,
          <code>TimetreeBrushView</code>. Drag-select it to zoom in on the original
          <code>TimetreeView</code>. You can drag this selection to focus different time
          slices. The original view is linked to the brush view via the <code>rangeBinding</code> and <code>brushRangeBinding</code> attributes respectively.
        </p>
        <p>
          You can also bind to the selected item in the hierarchy via the
          <code>selectionBinding</code> attribute. <strong>Try clicking</strong> on an item in the main view.
        </p>
      </figcaption>

      <p {{bindAttr class=":label :label-info selectedEvents::invisible"}}>
        You selected the event named <span class="example-selection">{{ selectedEvents.firstObject.label }}</span>.
      </p>

      {{view Ember.Timetree.TimetreeView contentBinding="App.ApiData" selectionBinding="selectedEvents" rangeBinding="eventsRange_example2"}}
      {{view Ember.Timetree.TimetreeBrushView contentBinding="App.ApiData" brushRangeBinding="eventsRange_example2"}}
    </div>

    </script>


   <script src="jquery.min.js"></script>
  <script src="handlebars.min.js"></script>
  <script src="ember.min.js"></script>
  <script src="d3.min.js"></script>
  <script src="ember-timetree.min.js"></script>

  <!-- Not required. Just for demo. -->
  <script src="app.js"></script>