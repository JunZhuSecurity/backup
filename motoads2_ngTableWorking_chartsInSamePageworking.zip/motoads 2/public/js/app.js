'use strict';

var motoAdsApp = angular.module('motoAdsApp', ['ngRoute', 'ngSanitize', 'ui.bootstrap', 'motoAdsServices']);
//var svd3ChartApp = angular.module('svd3ChartApp', ['nvd3ChartDirectives', 'svd3ChartServices']);

motoAdsApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
            when('/', {
              controller: 'AdvertsController',
              templateUrl: 'views/adverts.html'
            }).
            when('/addAdvert', {
              controller: 'AddAdvertController',
              templateUrl: 'views/addAdvert.html'
            }).
            when('/editAdvert/:advertId', {
              controller: 'EditAdvertController',
              templateUrl: 'views/editAdvert.html'
            }).
            when('/lineChart', {
                controller: 'lineChartTickValueCtrl',
                templateUrl: 'views/lineChart.html'
              });
            
            
            
            
            
  }]);


//svd3ChartApp.config(['$routeProvider',
//                   function($routeProvider) {
//                     $routeProvider.
//                     when('/linechart', {
//                       controller: 'lineChartTickValueCtrl',
//                       templateUrl: 'views/lineChart.html'
//                     });
//}]);