'use strict';

var motoAdsServices = angular.module('motoAdsServices', ['ngResource']);

motoAdsServices.factory('Brand', ['$resource', function($resource) {
    return $resource('/api/brands', {}, {});
  }]);

motoAdsServices.factory('Country', ['$resource', function($resource) {
    return $resource('/api/countries', {}, {});
  }]);

motoAdsServices.factory('Advert', ['$resource', function($resource) {
    return $resource('/api/adverts/:advertId', {}, {
       update: {method:'PUT', params: {advertId: '@_id'}}
    });
  }]);

//newly added
motoAdsServices.factory('Wflow', ['$resource', function($resource) {
    return $resource('/api/wflow/:startDate/:endDate/:appName/:wflowName/:hostName/:status', {}, {'get': {method: 'GET', isArray: true/*true*/}});
    
  }]);


//var svd3ChartServices = angular.module('svd3ChartServices', ['ngResource']);

motoAdsServices.factory('Chart', ['$resource', function($resource) {
    	return $resource('/api/linechart', {}, {});   
  }]);

motoAdsServices.factory('LinePlusBarChart', ['$resource', function($resource) {
	return $resource('/api/linePlusBarChart', {}, {});   
}]);

motoAdsServices.factory('StackedAreaChart', ['$resource', function($resource) {
	return $resource('/api/stackedAreaChart', {}, {});   
}]);
//modified July 15, 2014
motoAdsServices.factory('TreeGridChart', ['$resource', function($resource) {
	return $resource('/api/treeGridChart/:correlationId', {}, {});   
}]);
//newly modified
motoAdsServices.factory('HierarchicalBarChart', ['$resource', function($resource) {
	return $resource('/api/hierarchicalBarChart/:correlationId', {}, {});   
}]);


motoAdsServices.factory('ngGridChart', ['$resource', function($resource) {
	return $resource('/api/ngGridChart', {}, {});   
}]);

motoAdsServices.factory('crossfilterChart', ['$resource', function($resource) {
	return $resource('/api/crossfilterChart', {}, {});   
}]);



motoAdsServices.factory('forceableGraphChart', ['$resource', function($resource) {
	return $resource('/api/forceableGraphChart/:correlationId', {}, {});   
}]);

//newly added
motoAdsServices.factory('ngTable', ['$resource', function($resource) {
	return $resource('/api/ngTable', {}, {});   
}]);

motoAdsServices.factory('partitionChart', ['$resource', function($resource) {
	return $resource('/api/partitionChart', {}, {});   
}]);


//shared data between controllers through services
motoAdsServices.factory('sharedProperties', function(){
	var objectValue = {realObject:{"test": 5435}};// = {};
	var correlationId = "";//"ee796cea8474a";
	var queriedWflows = [];
	
	
	return {
		setCorrelationId: function(value){
			correlationId = value;
		},
	    getCorrelationId: function(){
	    	return correlationId;
	    },
	    
	    //newly added
	    getQueriedWflows: function(){
	    	return queriedWflows;
	    },
	    setQueriedWflows: function(value){
	    	queriedWflows = value;
	    },
		
		setObject: function(value){
			objectValue.realObject = value;
		},
		getObject: function(){
		return objectValue;
	}}
});
