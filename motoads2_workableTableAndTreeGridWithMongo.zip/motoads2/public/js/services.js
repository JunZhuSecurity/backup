'use strict';

var motoAdsServices = angular.module('motoAdsServices', ['ngResource']);

motoAdsServices.factory('Brand', ['$resource', function($resource) {
    return $resource('/api/brands', {}, {});
  }]);

motoAdsServices.factory('Country', ['$resource', function($resource) {
    return $resource('/api/countries', {}, {});
  }]);

motoAdsServices.factory('Advert', ['$resource', function($resource) {
    return $resource('/api/adverts/:advertId', {}, {
       update: {method:'PUT', params: {advertId: '@_id'}}
    });
  }]);

//newly added
//var svd3ChartServices = angular.module('svd3ChartServices', ['ngResource']);

motoAdsServices.factory('Chart', ['$resource', function($resource) {
    	return $resource('/api/linechart', {}, {});   
  }]);

motoAdsServices.factory('LinePlusBarChart', ['$resource', function($resource) {
	return $resource('/api/linePlusBarChart', {}, {});   
}]);

motoAdsServices.factory('StackedAreaChart', ['$resource', function($resource) {
	return $resource('/api/stackedAreaChart', {}, {});   
}]);
//modified July 15, 2014
motoAdsServices.factory('TreeGridChart', ['$resource', function($resource) {
	return $resource('/api/treeGridChart/:correlationId', {}, {});   
}]);

motoAdsServices.factory('HierarchicalBarChart', ['$resource', function($resource) {
	return $resource('/api/hierarchicalBarChart', {}, {});   
}]);


motoAdsServices.factory('ngGridChart', ['$resource', function($resource) {
	return $resource('/api/ngGridChart', {}, {});   
}]);

motoAdsServices.factory('crossfilterChart', ['$resource', function($resource) {
	return $resource('/api/crossfilterChart', {}, {});   
}]);



motoAdsServices.factory('forceableGraphChart', ['$resource', function($resource) {
	return $resource('/api/forceableGraphChart', {}, {});   
}]);

//newly added
motoAdsServices.factory('ngTable', ['$resource', function($resource) {
	return $resource('/api/ngTable', {}, {});   
}]);

motoAdsServices.factory('partitionChart', ['$resource', function($resource) {
	return $resource('/api/partitionChart', {}, {});   
}]);


//shared data between controllers through services
motoAdsServices.factory('sharedProperties', function(){
	var objectValue = {realObject:{"test": 5435}};// = {};
	var correlationId = "";
	
	
	
	return {
		setCorrelationId: function(value){
			correlationId = value;
		},
	    getCorrelationId: function(){
	    	return correlationId;
	    },
		
		setObject: function(value){
			objectValue.realObject = value;
		},
		getObject: function(){
		return objectValue;
	}}
});
