'use strict';

var motoAdsApp = angular.module('motoAdsApp', ['ngRoute', 'ngSanitize', 'ui.bootstrap', 'motoAdsServices', 'nvd3ChartDirectives', 'treeGrid', 'hierarchicalBar', 'ngGrid', 'ngTableModule', 'forceableGraph', 'partitionChart', 'angularDcDirectives']);
//var svd3ChartApp = angular.module('svd3ChartApp', ['nvd3ChartDirectives', 'svd3ChartServices']);

motoAdsApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
            when('/', {
              controller: 'AdvertsController',
              templateUrl: 'views/adverts.html'
            }).
            //newly added
            when('/', {
                controller: 'treeGridChartCtrl',
                templateUrl: 'views/adverts.html'
              }).
              when('/', {
                  controller: 'hierarchicalBarChartCtrl',
                  templateUrl: 'views/adverts.html'
                }).
                when('/', {
                    controller: 'ngTableCtrl',
                    templateUrl: 'views/adverts.html'
                  }).
                  when('/', {
                      controller: 'wflowCtrl',
                      templateUrl: 'views/adverts.html'
                    }).
                  
                  
                   when('/', {
         controller: 'forceableGraphChartCtrl',
         templateUrl: 'views/adverts.html'
       }).
            //above is newly added
            
            
            
            when('/addAdvert', {
              controller: 'AddAdvertController',
              templateUrl: 'views/addAdvert.html'
            }).
            when('/editAdvert/:advertId', {
              controller: 'EditAdvertController',
              templateUrl: 'views/editAdvert.html'
            }).
            when('/lineChart', {
                controller: 'lineChartTickValueCtrl',
                templateUrl: 'views/lineChart.html'
              }).
            //attention!!!!! it is . not ;
    when('/linePlusBarChart', {
        controller: 'linePlusBarChartCtrl',
        templateUrl: 'views/linePlusBarChart.html'
      }). //attention!!!! if it is the last when, then, 
         
            //attention!!!!! it is . not ;
    when('/stackedAreaChart', {
        controller: 'stackedAreaChartCtrl',
        templateUrl: 'views/stackedAreaChart.html'
      }). //attention!!!! if it is the last when, then,    
      
      //newly added
  //attention!!!!! it is . not ;
  when('/treeGridChart/:correlationId', {
      controller: 'treeGridChartCtrl',
      templateUrl: 'views/treeGridChart.html'
    }).
    
    //newly added
    when('/dcfilter', {
        controller: 'dcfilterCtrl',
        templateUrl: 'dcfilter.html'
      }).
    
    
    //newly modified
    when('/hierarchicalBarChart/:correlationId', {
        controller: 'hierarchicalBarChartCtrl',
        templateUrl: 'views/hierarchicalBarChart.html'
      }).
      
      when('/ngGridChart', {
          controller: 'ngGridChartCtrl',
          templateUrl: 'views/ngGridChart.html'
        }).
        
        when('/crossfilterChart', {
            controller: 'crossfilterChartCtrl',
            templateUrl: 'views/crossfilterChart.html'
          })
          //newly added
          .when('/ngTable', {
              controller: 'ngTableCtrl',
              templateUrl: 'views/ngTable.html'
            })
  //newly added
    .when('/forceableGraphChart/:correlationId', {
        controller: 'forceableGraphChartCtrl',
        templateUrl: 'views/forceableGraphChart.html'
      })
      
      .when('/partitionChart', {
          controller: 'partitionChartCtrl',
          templateUrl: 'views/partitionChart.html'
        })
        
        //newly added
        .when('/myAngularDc', {
            controller: 'myAngularDcCtrl',
            templateUrl: 'myAngularDc.html'
          });
    
            
  }]); 


//svd3ChartApp.config(['$routeProvider',
//                   function($routeProvider) {
//                     $routeProvider.
//                     when('/linechart', {
//                       controller: 'lineChartTickValueCtrl',
//                       templateUrl: 'views/lineChart.html'
//                     });
//}]);